Source: <https://grabcad.com/library/extruder-bracket-for-3d-printer-creality-ender-5-s1-1>
